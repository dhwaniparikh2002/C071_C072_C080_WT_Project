<?php
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];


if(!empty($firstname) || !empty($lastname) || !empty($email) || !empty($password) || !empty($cpassword)){
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword ="";
	$dbname = "crystal";

	$conn = new mysqli($host, $dbUsername,$dbPassword,$dbname);

	if(mysqli_connect_error()){
		die('Connect Error('. mysqli_connect _errno().')'. mysqli_connect_error());
	}else{
		$SELECT ="SELECT email FROM register WHERE email= ? Limit 1";
		$INSERT = "INSERT Into register (fname, lname, email, password,cpassword) values(?,?,?,?,?)";

		$stmt = $conn->prepare($SELECT);
		$stmt->bind_param("s",$email);
		$stmt->execute();
		$stmt->bind_result($email);
		$stmt->store_result();
		$rnum = $stmt->num_rows;

		if($rnum ==0){
			$stmt->close();

			$stmt = $conn->prepare($INSERT);
			$stmt->bind_param("sssss", $firstname,$lastname,$email,$password,$cpassword);
			$stmt->execute();
			echo "New record inserted successfully";
			header("Location: login.html");

		}else{
			echo "already exists";
		}
		$stmt->close();
		$conn->close();

	}
}else{
	echo "invalid";
}
?>