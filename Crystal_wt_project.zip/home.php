<?php
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword ="";
	$dbname = "crystal";
	$conn = new mysqli($host, $dbUsername,$dbPassword,$dbname);
	
$email = $_POST['email'];
$password =$_POST['password'];
$submit =$_POST['submit'];


	$rs=mysqli_query($conn,"select * from register where email='$email' and password='$password'");
	
	if(mysqli_num_rows($rs)<1)
	{
		$found="N";
	}
	else
	{
		$_SESSION["email"]=$email;
	}

if (isset($_SESSION["email"]))
{
	header("Location: home.html");
	exit();
 }
 else{
 	 header("Location: login.html");	
	
 }

?>