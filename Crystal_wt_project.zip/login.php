<style type="text/css">
	td{
		padding: 10px;
	}
	table,th,tr,td{
		border: 3px solid black;
	}
</style>
<?php
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['password'];


if(!empty($firstname) || !empty($lastname) || !empty($email) || !empty($password) || !empty($confirm)){
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword ="";
	$dbname = "crystal";
	$conn = new mysqli($host, $dbUsername,$dbPassword,$dbname);
	$selectQuery = "select * from signup_details";
	$data = mysqli_query($conn, $selectQuery);
	$totalrows = mysqli_num_rows($data);

	

	if(mysqli_connect_error()){
		echo "connection Err!!!!!!!";
	}else{
		$SELECT ="SELECT email FROM signup_details WHERE email= ? Limit 1";
		$INSERT = "INSERT Into signup_details (fname, lname, email, password) values(?,?,?,?)";

		$stmt = $conn->prepare($SELECT);
		$stmt->bind_param("s",$email);
		$stmt->execute();
		$stmt->bind_result($email);
		$stmt->store_result();
		$rnum = $stmt->num_rows;

		if($rnum ==0){
			$stmt->close();

			$stmt = $conn->prepare($INSERT);
			$stmt->bind_param("ssss", $firstname,$lastname,$email,$password);
			$stmt->execute();
		}

		$stmt->close();
		$conn->close();
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Crystal - Login</title>
	<meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap.min.css"> 
    <link rel="stylesheet" href="style.css">
    <link href="animate.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Oxygen:400,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Qwigley" />
    <link href="font-awesome.min.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="wrapper">
		<div class="col-md-12">
			<div class="brand wow fadeIn" data-wow-delay="0.1s">Crystal</div>
			<div class="heading-inner">Login</div><br><br>
			<div style="height: 300px; width: 500px; margin-left: 450px;">
				<form action="home.html" name="LoginForm" onsubmit="return validateForm()" method="post">
					<label>Username: </label>
					<input type="text" name="uname" ><br><br>
					<label>Password: </label>
					<input type="Password" name="password" ><br><br>
          <center>
					<button type="Submit" class="btn btn-outline-secondary">Submit</button></center>
				</form><br><br>
				<a href="signup.html">Do not have an account? Sign up here!</a>
			</div>
			<div class="footer col-md-6 col-xs-offset-3">
            	<h5>Copyright 2020</h5>
          	</div>
		</div>
	</div>
	<script type="text/javascript">
		
	</script>
  <!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="/__/firebase/7.19.1/firebase-app.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="/__/firebase/7.19.1/firebase-analytics.js"></script>

<!-- Initialize Firebase -->
<script src="/__/firebase/init.js"></script>
</body>
</html>