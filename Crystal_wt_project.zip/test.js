var express=require('express')
var app=new express();
var port=8080;

app.use(express.static('public'));
require('./index')(app);

app.listen(port,()=>{
    console.log('server is running:'+port)
})