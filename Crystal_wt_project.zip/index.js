module.exports=(app)=>{
    app.get('/',(req,res)=>
{
    res.send("This is root page")
});

app.get('/login.html',(req,res)=>
{
    res.sendFile(__dirname+'/login.html')
});

app.get('/home.html',(req,res)=>
{
    res.sendFile(__dirname+'/home.html');
});
}